# select a random number
sample(1:10, 10, replace=TRUE)

# () brackets / parentheses
# [] square brackets
# {} braces / curly brackets

randomnumber <- function() { sample(1:10,1) }

randomnumber()

# can you modify this function to give 20 numbers between 1 and 10
sample(1:10,20, replace=TRUE)

# thanks Yash, Nishat and Sweta
randomnumber <- function() {sample(1:10,20, replace=TRUE)}
randomnumber()

x=20
x^2
# can you make a function to calculate the square of a number?
function_name <- function(x) { some_command(x) }
square <- function(x) {x^2}
square(9)

# Create a function to find the 4th power of a number (x)
powerOf4 <- function (x) { x^4 }
powerOf4 (44)

# Create a function to calculate the square root of numbers 1:10
9^(1/2)
sqrt(9)
squareroot_func <- function (x) { x^(1/2) }
squareroot_func(1:10)

squareroot_func <- function () { sqrt(1:10) }
squareroot_func()

squareroot_func <- function () { (1:10)^(1/2) }
squareroot_func()

cubed <- function(x) {
  x^3
}
cubed(3)

cubedsum <- function(x,y) {
  z <- cubed(x) + cubed(y)
  return(z)
}
cubedsum(12,13)

# Conditionals

if (condition) { command() }
2>1
if (2>1) { print("ok") }
2<3
2==3
2!=3

# create an if statement to print "OK" if 9 is less than 10
if  (9<10) { print ("ok") }

# now we're calculating a squareroot
# if a number (x) is negative, give a warning("No negative numbers allowed")
x<-sample(-10:10,1)
x<0
if (x < 0) { 
  warning("No negatives allowed") 
} else {
  x^(1/3)
}

# can you calculate the cubed root, throwing a warning for negative numbers?
if (x < 0) { 
  warning("No negatives allowed") 
} else {
  x^(1/3)
}

# A function to calculate the cubed root, throwing a warning for negative numbers?
cubedroot <- function(x) {
  if (x < 0) { 
    warning("No negatives allowed") 
  } else {
    x^(1/3)
  }
}
cubedroot(27)

# more than one condition
if(3>2 & 5>4) {print("ok")} # & == AND

if(3>2 | 5>10) {print("ok")} # | == OR

# loops
for (i in 1:5) {
  print(i^2)
}

for (i in 1:5) {
  i^2
}

res <- for (i in 1:5) {
  print(i^2)
}
res

# sapply
res <- sapply(1:5, square)
res

# calculate for me the first 10 cubes using sapply.
res <- sapply(1:10, cubed)
res

# calculate for me the cubed root of number 1 to 100 using sapply
res <- sapply(1:100, cubedroot)

res

# run with lapply
res <- lapply(1:10, cubed)
res

cubeandroot <- function(x) {
  mycube <- cubed(x)
  mycubedroot <- cubedroot(x)
  result <- c(mycube,mycubedroot)
  return(result)
}
cubeandroot(3)

# lapply gived output as list
lapply(1:10, cubeandroot)
# sapply give output as matrix
sapply(1:10,cubeandroot)

# apply
# MARGIN is 1 for rows and 2 for columns
apply(x,MARGIN,FUN)
mat<-matrix(rbinom(100,50,0.8),nrow = 5)
head(mat)
apply(mat,1,median)
apply(mat,2,median)

# Use apply to calculate the mean of each column in this matrix
apply(mat,2,mean)

# Replicate
randomnumber <- function() {sample(1:10,1, replace=TRUE)}
randomnumber()

mean(replicate(10,randomnumber()))
mean(replicate(1000000,randomnumber()))
